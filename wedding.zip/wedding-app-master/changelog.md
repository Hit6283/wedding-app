<h3 align="center">
  <a href="https://github.com/wforguo/wedding-app" title="趣婚礼">趣婚礼</a>
</h3>

<p align="center">
  <a href="https://forguo-1302175274.cos.ap-shanghai.myqcloud.com/wedding/assets/img/qrcode.jpeg" title="趣婚礼 Logo"><img alt="趣婚礼 Logo" src="https://forguo-1302175274.cos.ap-shanghai.myqcloud.com/wedding/assets/img/qrcode.jpeg" width="180"></a>
</p>

<p align="center">
    <a href="https://github.com/wforguo/wedding-app" title="趣婚礼">基于Taro + 云开发 打造婚礼邀请函</a>
</p>

## 更新日志
